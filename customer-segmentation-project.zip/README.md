# Customer Segmentation Project

Segment customers based on behavior and demographics using clustering.

## Features
- K-Means customer segmentation
- Customer analytics and profiling
- Visualizations of segments
- GitHub-ready project structure

## Quick Start
```bash
pip install -r requirements.txt
python src/generate_sample_data.py
python src/customer_segmentation.py
```
