import pandas as pd
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans
import matplotlib.pyplot as plt

df = pd.read_csv('data/customers.csv')
X = df[['Age','Income','SpendingScore']]
Xs = StandardScaler().fit_transform(X)

kmeans = KMeans(n_clusters=4, random_state=42, n_init=10)
df['Segment'] = kmeans.fit_predict(Xs)

print(df.groupby('Segment').mean())

plt.scatter(df['Income'], df['SpendingScore'], c=df['Segment'])
plt.xlabel('Income')
plt.ylabel('SpendingScore')
plt.title('Customer Segments')
plt.savefig('reports/customer_segments.png')
print('Saved visualization to reports/customer_segments.png')
