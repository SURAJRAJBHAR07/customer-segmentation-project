import numpy as np, pandas as pd
np.random.seed(42)
n=500
df=pd.DataFrame({
    'Age': np.random.randint(18,70,n),
    'Income': np.random.randint(20000,120000,n),
    'SpendingScore': np.random.randint(1,100,n)
})
df.to_csv('data/customers.csv', index=False)
print('Sample data created.')
